describe('Homepage Verification', () => {
  it('should load homepage and display main elements', () => {
    cy.visit('/');
    cy.contains('Kitchen Sink').should('be.visible');
    cy.get('h1').should('contain', 'Welcome to Cypress');
    cy.get('a').contains('Commands').should('be.visible');
  });
});
