describe('Estimate Price - UI + API Mocking', () => {
  beforeEach(() => {
    cy.intercept('GET', `${Cypress.env('api')}*`, {
      statusCode: 200,
      body: {
        basePrice: 100000,
        distanceFee: 20000,
        weightFee: 30000,
        discount: 10000
      }
    }).as('getEstimate');

    cy.visit('/estimate');
  });

  it('Displays correct total price from mocked API', () => {
    cy.get('input[name="weight"]').type('2');
    cy.get('select[name="location"]').select('HCM');
    cy.wait('@getEstimate');

    cy.get('[data-testid="total-price"]').should('contain', '140,000');
  });
});
